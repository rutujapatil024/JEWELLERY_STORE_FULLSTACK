<h1>Pre-Requiste</h1>
1. Install NodeJs<br/>
2. Install MongoDB.
